package com.personajes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonajesApplicationTests {

	@Test
	void contextLoads() {
	}

}
