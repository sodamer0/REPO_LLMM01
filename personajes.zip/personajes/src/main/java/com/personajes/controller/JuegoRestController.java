package com.personajes.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import ch.qos.logback.classic.Logger;
import jakarta.servlet.http.HttpServletRequest;


@RequestMapping("/")
@RestController
public class JuegoRestController {
	
	//Declare variables
	
	

	
	@GetMapping("/")
	public boolean hello() {
		return true;
	}
	
	@GetMapping("/pista1")
	public String pista1(HttpServletRequest request) {
		getIp(request);
		return "Tu pista 1";
	}
	
	
	@GetMapping("/resolver/{name}")
	public boolean pista1Resolver(@PathVariable String name) {
		return true;
	}
	
	
	
	public void getIp(HttpServletRequest request) {
        String ip = request.getHeader("X-Forwarded-For");
        if (ip == null) {
            ip = request.getRemoteAddr();
        }
        System.out.println("IP de la request: " + ip);
    }


}

